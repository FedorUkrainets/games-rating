const { readData, writeData } = require("./parse");

module.exports = { readData, writeData };
