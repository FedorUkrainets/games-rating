const mimeTypes = require('./mime-types')
const staticFile = require('./static-file')

modeule.exports = {
    mimeTypes,
    staticFile
};